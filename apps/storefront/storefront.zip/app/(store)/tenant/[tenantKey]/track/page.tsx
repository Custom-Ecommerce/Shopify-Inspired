import { OrderTrackingPage } from "@markaz/theme-mustafa";
import { queryParam } from "@/lib/query-param";

const ORDER_REFERENCE_MAX = 40;

/** Order tracking. An ?order= reference prefills the form, which is how the confirmation page links here. */
export default async function TenantTrackPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string | string[] }>;
}) {
  const orderId = queryParam((await searchParams).order, ORDER_REFERENCE_MAX);
  return <OrderTrackingPage orderId={orderId || undefined} />;
}
