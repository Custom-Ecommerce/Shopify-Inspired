import { CheckoutPage } from '@markaz/theme-mustafa';

/** Checkout. Orders go through the store's BFF; the tenant layout has already checked the store is serving. */
export default function TenantCheckoutPage() {
  return <CheckoutPage />;
}
