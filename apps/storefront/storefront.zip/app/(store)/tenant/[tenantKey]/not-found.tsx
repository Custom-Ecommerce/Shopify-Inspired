import { NotFoundPage } from "@markaz/theme-mustafa";

/** The store's own not-found page. It renders inside the store's layout, so the header and footer stay in place. */
export default function TenantNotFound() {
  return <NotFoundPage />;
}
