import { CartPage } from '@markaz/theme-mustafa';

/** The store's cart. Its contents and prices come from the storefront provider the tenant layout mounts. */
export default function TenantCartPage() {
  return <CartPage />;
}
