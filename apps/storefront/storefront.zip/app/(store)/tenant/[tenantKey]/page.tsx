import React from 'react';

export default async function TenantPage({
  params,
}: {
  params: Promise<{ tenantKey: string }>;
}) {
  const resolvedParams = await params;
  return (
    <main className="p-8">
      <h1 className="text-3xl font-bold">Welcome to {resolvedParams.tenantKey}</h1>
      <p className="mt-4 text-gray-600">This is a placeholder for the tenant storefront.</p>
    </main>
  );
}
