import { notFound } from "next/navigation";
import { OrderConfirmationPage } from "@markaz/theme-mustafa";

export default async function DemoOrderPage({
  params,
}: {
  params: Promise<{ themeSlug: string; orderId: string }>;
}) {
  const { themeSlug, orderId } = await params;
  // Mock order ids have the form ORD-<number>. A real backend will look the order up instead.
  if (themeSlug !== "mustafa" || !/^ORD-[0-9]+$/.test(orderId)) notFound();
  return <OrderConfirmationPage orderId={orderId} />;
}
