import { notFound } from "next/navigation";
import { OrderTrackingPage } from "@markaz/theme-mustafa";
import { queryParam } from "@/lib/query-param";

const ORDER_REFERENCE_MAX = 40;

/** Order tracking on the demo. Orders placed in this session are found; the demo keeps nothing between sessions. */
export default async function DemoTrackPage({
  params,
  searchParams,
}: {
  params: Promise<{ themeSlug: string }>;
  searchParams: Promise<{ order?: string | string[] }>;
}) {
  const { themeSlug } = await params;
  if (themeSlug !== "mustafa") notFound();
  const orderId = queryParam((await searchParams).order, ORDER_REFERENCE_MAX);
  return <OrderTrackingPage orderId={orderId || undefined} />;
}
