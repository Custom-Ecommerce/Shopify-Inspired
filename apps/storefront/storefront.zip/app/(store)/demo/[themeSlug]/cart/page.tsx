import { notFound } from "next/navigation";
import { CartPage } from "@markaz/theme-mustafa";

export default async function DemoCartPage({
  params,
}: {
  params: Promise<{ themeSlug: string }>;
}) {
  const { themeSlug } = await params;
  if (themeSlug !== "mustafa") notFound();
  return <CartPage />;
}
