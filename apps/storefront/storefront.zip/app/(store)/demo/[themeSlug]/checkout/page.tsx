import { notFound } from "next/navigation";
import { CheckoutPage } from "@markaz/theme-mustafa";

export default async function DemoCheckoutPage({
  params,
}: {
  params: Promise<{ themeSlug: string }>;
}) {
  const { themeSlug } = await params;
  if (themeSlug !== "mustafa") notFound();
  return <CheckoutPage />;
}
