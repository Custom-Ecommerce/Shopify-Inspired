import "../../../globals.css";
import React from 'react';
import { Layout } from '@markaz/theme-mustafa';

export default async function DemoLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ themeSlug: string }>;
}) {
  const resolvedParams = await params;
  return (
    <div className="demo-provider-boundary">
      <div className="bg-blue-600 text-white text-center py-2 text-sm font-medium">
        Previewing Theme: {resolvedParams.themeSlug} (Mock checkout: no orders are saved)
      </div>
      <Layout
        store={{
          name: 'Demo Store',
          logoUrl: null,
          announcement: null,
          currency: 'PKR',
          locale: 'en-PK',
        }}
        nav={{
          links: [
            { label: 'Products', href: '/products' },
            { label: 'Track order', href: '/track' },
          ],
        }}
        footer={{ links: [], copyright: 'Demo storefront preview' }}
        lang="en"
        dir="ltr"
      >
        {children}
      </Layout>
    </div>
  );
}
