import React from 'react';

export default async function DemoPage({
  params,
}: {
  params: Promise<{ themeSlug: string }>;
}) {
  const resolvedParams = await params;
  return (
    <main className="p-8 max-w-4xl mx-auto mt-12 bg-white rounded-xl shadow-sm border border-gray-200">
      <h1 className="text-3xl font-bold text-gray-900">Theme Demo: {resolvedParams.themeSlug}</h1>
      <p className="mt-4 text-gray-600">This is a placeholder preview for the requested theme. Checkout functionality is disabled in demo mode.</p>
    </main>
  );
}
