import { notFound } from "next/navigation";
import { CatalogPage } from "@markaz/theme-mustafa";
import { loadCatalogPage } from "@markaz/storefront-data/server";
import { resolveTransport } from "@/lib/sources";

export default async function DemoProductsPage({
  params,
}: {
  params: Promise<{ themeSlug: string }>;
}) {
  const { themeSlug } = await params;
  if (themeSlug !== "mustafa") notFound();
  // Demo routes always resolve to fixtures (kind: "demo"), unless STOREFRONT_DATA_SOURCE says otherwise.
  const transport = await resolveTransport({ kind: "demo", themeSlug });
  if (!transport) notFound();
  return <CatalogPage data={await loadCatalogPage(transport)} />;
}
