import { notFound } from "next/navigation";
import { ProductPage } from "@markaz/theme-mustafa";

export default async function DemoProductPage({
  params,
}: {
  params: Promise<{ themeSlug: string; slug: string }>;
}) {
  const { themeSlug, slug } = await params;
  if (themeSlug !== "mustafa") notFound();
  return <ProductPage slug={slug} />;
}
