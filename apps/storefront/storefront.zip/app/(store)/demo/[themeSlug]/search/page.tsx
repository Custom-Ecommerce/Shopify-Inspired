import { notFound } from "next/navigation";
import { SearchPage, UnavailablePage } from "@markaz/theme-mustafa";
import { MAX_SEARCH_LENGTH, storePaths } from "@markaz/storefront-data";
import { loadSearchPage } from "@markaz/storefront-data/server";
import { resolveTransport } from "@/lib/sources";
import { queryParam } from "@/lib/query-param";

/** Product search on the demo. The demo reads fixtures, so the search covers the demo catalogue. */
export default async function DemoSearchPage({
  params,
  searchParams,
}: {
  params: Promise<{ themeSlug: string }>;
  searchParams: Promise<{ q?: string | string[] }>;
}) {
  const { themeSlug } = await params;
  if (themeSlug !== "mustafa") notFound();
  const query = queryParam((await searchParams).q, MAX_SEARCH_LENGTH);
  const transport = await resolveTransport({ kind: "demo", themeSlug });
  if (!transport) notFound();

  const outcome = await loadSearchPage(transport, query);
  if (outcome.status === "unavailable") {
    return (
      <UnavailablePage
        message="Search is not available right now. Please try again in a moment."
        retryHref={query ? storePaths.searchFor(query) : storePaths.search}
      />
    );
  }
  return <SearchPage query={query} results={outcome.results} />;
}
