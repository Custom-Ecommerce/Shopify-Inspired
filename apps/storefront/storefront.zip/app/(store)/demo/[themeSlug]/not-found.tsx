import { NotFoundPage } from "@markaz/theme-mustafa";

/** The demo's not-found page, rendered inside the demo layout. */
export default function DemoNotFound() {
  return <NotFoundPage />;
}
