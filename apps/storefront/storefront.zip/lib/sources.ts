import "server-only";

import type { ThemeSlug } from "@markaz/platform-kit/themes";
import {
  TransportConfigError,
  normalizeBaseUrl,
  parseDataSourceSetting,
  parseRemoteMode,
  resolveTransportKind,
  selectTransport,
  type BffStoreLookup,
  type StorefrontTransport,
} from "@markaz/storefront-data/server";
import { resolveStore } from "@/lib/tenancy/resolve-store";

/**
 * Where a storefront request's data comes from (blueprint section 2.2). Routes build one of these
 * from their params. Containers receive it and never read the URL themselves.
 */
export type StorefrontSource =
  | { kind: "tenant"; key: string } // T3: slug
  | { kind: "demo"; themeSlug: ThemeSlug } // T2: fixtures, checkout disabled
  | { kind: "domain"; host: string }; // T4: custom domain (needs by=domain, finding F4)

// Read once when the server loads this module. A typo in an env value fails the build or the boot,
// not a shopper's request. With NODE_ENV=production, STOREFRONT_DATA_SOURCE=mock also fails here.
const DATA_SOURCE = parseDataSourceSetting(process.env.STOREFRONT_DATA_SOURCE);
const REMOTE_MODE = parseRemoteMode(process.env.STOREFRONT_REMOTE_MODE);
resolveTransportKind({ sourceKind: "tenant", dataSource: DATA_SOURCE, nodeEnv: process.env.NODE_ENV });

/**
 * Returns the transport for a source, or null when a tenant's store is not serving. The tenant
 * layout normally redirects first, so callers turn null into notFound().
 */
export async function resolveTransport(source: StorefrontSource): Promise<StorefrontTransport | null> {
  const kind = resolveTransportKind({
    sourceKind: source.kind,
    dataSource: DATA_SOURCE,
    nodeEnv: process.env.NODE_ENV,
  });
  if (kind === "mock") return selectTransport("mock");

  if (source.kind !== "tenant") {
    throw new TransportConfigError("Only tenant sources can use the remote transport so far.");
  }

  // Shares React's per-request cache with the tenant layout, so this is not a second backend call.
  const lookup = await resolveStore(source.key, "slug");
  if (lookup.outcome !== "ok") return null;

  return selectTransport("remote", {
    baseUrl: normalizeBaseUrl(process.env.SELLER_BACKEND_API_URL || "http://localhost:4001"),
    storeId: lookup.store.id,
    mode: REMOTE_MODE,
  });
}

/**
 * The BFF's view of a store: resolves the tenant and binds a remote transport to it, or says why it cannot. The transport
 * carries the shopper's IP, so the backend's per-client limits apply to the shopper and not to this server.
 */
export async function resolveOrderTransport(key: string, clientIp: string | null): Promise<BffStoreLookup> {
  const kind = resolveTransportKind({ sourceKind: "tenant", dataSource: DATA_SOURCE, nodeEnv: process.env.NODE_ENV });
  if (kind === "mock") return { outcome: "ok", transport: selectTransport("mock") };

  const lookup = await resolveStore(key, "slug");
  if (lookup.outcome === "not-found") return { outcome: "not-found" };
  if (lookup.outcome === "unavailable") return { outcome: "inactive", status: lookup.status };
  if (lookup.outcome === "error") return { outcome: "error" };

  return {
    outcome: "ok",
    transport: selectTransport("remote", {
      baseUrl: normalizeBaseUrl(process.env.SELLER_BACKEND_API_URL || "http://localhost:4001"),
      storeId: lookup.store.id,
      mode: REMOTE_MODE,
      clientIp,
    }),
  };
}
