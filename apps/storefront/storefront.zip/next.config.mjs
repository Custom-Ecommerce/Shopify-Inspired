/** @type {import('next').NextConfig} */
const nextConfig = {
  allowedDevOrigins: ["theme.mustafa.localhost", "*.localhost", "localhost"],
  // The shared workspace package ships TypeScript source (see its package.json `exports`).
  transpilePackages: [
    "@markaz/platform-kit",
    "@markaz/storefront-data",
    "@markaz/storefront-theme-kit",
    "@markaz/theme-mustafa",
  ],
  images: {
    // Tenant product and store media is served from Cloudinary (F15).
    remotePatterns: [
      {
        protocol: "https",
        hostname: "res.cloudinary.com",
      },
    ],
  },
};

export default nextConfig;
